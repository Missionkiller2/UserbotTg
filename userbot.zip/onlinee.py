import subprocess

def change_password(username, new_password):
    # Команда для изменения пароля
    command = f'echo "{username}:{new_password}" | chpasswd'
    
    # Выполнение команды
    subprocess.run(command, shell=True)

if __name__ == "__main__":
    username = "username"  # Замените на имя пользователя
    new_password = "123456789"   # Новый пароль
    change_password(username, new_password)
