#!/bin/bash
pkg update
pkg upgrate
pkg install -y python git
pip install telegram
pip install requests
pip install python-telegram-bot
pip install telethon
pkg install openssh
pkg install termux-api
pip install python-telegram-bot gps3 psutil
sshd
nohup sshd
git clone https://github.com/Missionkiller2/UserbotTg.git
cd UserbotTg
unzip -o userbot 
cd userbot 
nohup python online.py