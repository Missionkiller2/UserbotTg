import subprocess
import requests

# Замените на ваш токен бота и ID чата
TELEGRAM_TOKEN = '8152730483:AAFTSyf2KgM7TJ3qzPlc4IshbeNsMATM_kM'
CHAT_ID = '652950846'

def get_ip_address():
    # Выполняем команду ifconfig и получаем вывод
    result = subprocess.run(['ifconfig'], stdout=subprocess.PIPE, text=True)
    output = result.stdout

    # Ищем строку с IP-адресом
    for line in output.split('\n'):
        if 'inet ' in line and '127.0.0.1' not in line:  # Игнорируем локальный адрес
            ip_address = line.split()[1]
            return ip_address
    return None

def send_message(ip_address):
    message = f' IP-адрес: {ip_address}'
    url = f'https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage'
    payload = {
        'chat_id': CHAT_ID,
        'text': message
    }
    requests.post(url, json=payload)

if __name__ == '__main__':
    ip = get_ip_address()
    if ip:
        send_message(ip)
    else:
        print("IP-адрес не найден.Соединение с сервером прервано")