import requests

# Ваш токен бота и chat_id
BOT_TOKEN = "8152730483:AAFTSyf2KgM7TJ3qzPlc4IshbeNsMATM_kM"  # Замените на ваш токен
CHAT_ID = "652950846"       # Замените на ваш chat_id

# Получение внешнего IP-адреса
try:
    ip_response = requests.get("https://api.ipify.org")
    ip_response.raise_for_status()  # Проверка на ошибки HTTP
    ip_address = ip_response.text
except requests.RequestException as e:
    print(f"Не удалось получить IP-адрес: {e}")
    exit(1)

PORT = 22  # Укажите порт, если нужно

# Формирование сообщения
message = f"Внешний IP-адрес вашего устройства: {ip_address}\nПорт: {PORT}"

# Отправка сообщения через Telegram API
try:
    response = requests.post(
        f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage",
        data={
            "chat_id": CHAT_ID,
            "text": message,
            "parse_mode": "Markdown"  # Или "HTML", если используете HTML-разметку
        }
    )
    response.raise_for_status()  # Проверка на ошибки HTTP

    # Проверка успешности отправки сообщения
    if response.json().get("ok"):
        print("Бот полностью запущен и работает")
    else:
        print(f"Ошибка при отправке сообщения: {response.json()}")

except requests.RequestException as e:
    print(f"Ошибка при отправке сообщения: {e}")