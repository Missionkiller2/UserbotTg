nohup geo.py
python geo.py