import logging
from telegram import Update
from telegram.ext import Updater, CommandHandler, CallbackContext
from gps3 import GPS  # Изменено на GPS

# Настройка логирования
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)  # Исправлено на __name__

# Функция для получения местоположения
def get_location():
    gps_socket = GPS()  # Используем GPS вместо GPS3
    data_stream = gps_socket.stream()
    gps_socket.start()
    
    # Получаем данные GPS
    for data in data_stream:
        if data:
            latitude = data.get('lat')
            longitude = data.get('lon')
            gps_socket.stop()
            return latitude, longitude

# Команда /geo
def geo(update: Update, context: CallbackContext) -> None:
    location = get_location()
    if location:
        lat, lon = location
        update.message.reply_text(f"Ваше местоположение: https://www.google.com/maps?q={lat},{lon}")
    else:
        update.message.reply_text("Не удалось получить местоположение.")

def main() -> None:
    # Вставьте свой токен бота
    updater = Updater("7824730955:AAH7OsaqAjkw-xnvPkR3eeWynCHYASRwGwo")

    # Получаем диспетчер для регистрации обработчиков
    dispatcher = updater.dispatcher

    # Регистрация команды /geo
    dispatcher.add_handler(CommandHandler("geo", geo))

    # Запуск бота
    updater.start_polling()

    # Ожидание завершения работы
    updater.idle()

if __name__ == '__main__':  # Исправлено на __name__
    main()