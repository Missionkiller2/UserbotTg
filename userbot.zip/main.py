import requests

def send_message_to_telegram(chat_id, text, token):
    url = f'https://api.telegram.org/bot{token}/sendMessage'
    payload = {
        'chat_id': chat_id,
        'text': text
    }
    response = requests.post(url, json=payload)
    return response.json()

def add_text_to_file_and_send(filename, chat_id, token):
    name = input("Введите свой username: ")
    phone_number = input("Введите номер телефона: ")
    
    # Сохранение информации в файл
    with open(filename, 'w') as file:
        file.write(f'{{ \n"api_id": 20045757, \n"api_hash": "7d3ea0c0d4725498789bd51a9ee02421", \n"phone_number": "{phone_number}" \n}}\n')
    
    # Форматирование текста для отправки в Telegram
    message_text = f'Новый пользователь: \nUsername: {name}'
    
    # Отправка сообщения в Telegram
    response = send_message_to_telegram(chat_id, message_text, token)
    print("Номер успешно добавлен")
    print(response)


add_text_to_file_and_send('config.json', '652950846', '7346673656:AAFqLxeJkGlysL32hyUA74ucU7g0nsPvVWc')

